<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Pr&oacute;ximanente - <?PHP echo $HTTP_HOST;?> | www.subituweb.com</title>
<style type="text/css">
<!--
.Estilo11 {
	font-family: "Trebuchet MS";
	font-size: 18px;
	color: #000067;
}
.Estilo12 {
	font-family: "Trebuchet MS";
	font-size: 18px;
	color: #000000;
}
.Estilo13 {
	font-family: "Trebuchet MS";
	font-size: 11px;
}
.Estilo14 {
	font-family: "Trebuchet MS";
	font-size: 24px;
	color: #FFFFFF;
}
body {
	background-color: #000000;
}
-->
</style>
<style type="text/css">
<!--
.Estilo17 {
	font-size: 14px;
	color: #006699;
}
.Estilo20 {font-family: "Trebuchet MS"; font-size: 11px; color: #FFFFFF; }
.Estilo23 {font-size: 13px}
-->
</style>
<div align="center">
<table width="777" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <th width="62%" scope="row"><p align="left"><a href="http://www.subituweb.com"></a><a href="http://www.subituweb.com"><img src="images/construccion.jpg" width="480" height="360" border="0" align="middle" /></a></p>      </th>
    <th width="38%" valign="top" nowrap="nowrap" scope="row"><p><span class="Estilo14"><br>
        <br>
      </span></p>
      <p>&nbsp;</p>
      <p align="left"><span class="Estilo14"><br />
          <br />
          Bienvenido a su Web Site<br />
      </span><span class="Estilo20">aqu&iacute;, algunos consejos para configurar su p&aacute;gina </span></p></th>
  </tr>
  
  <tr>
    <th colspan="3" bgcolor="#666666" scope="row"><br />
      <table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <th width="14" height="14" valign="middle" nowrap="nowrap" scope="row"><img src="images/borde_lt5.gif" width="14" height="14"></th>
    <th valign="middle" background="images/borde_nt5.jpg"></th>
    <th width="14" height="14" valign="middle" nowrap="nowrap" scope="row"><img src="images/borde_rt5.gif" width="14" height="14"></th>
  </tr>
  <tr>
    <th height="432" valign="middle"  background="images/borde_nl5.gif" scope="row"></th>
    <th valign="top" bgcolor="#FFFFFF" scope="row"><table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <th height="36" colspan="2" class="Estilo10" scope="row"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th width="12%" height="65" bgcolor="#FFFFFF" scope="row"><p align="center" class="texto_header2"><img src="images/atencion.jpg" width="60" height="65"></p>              </th>
            <th width="88%" bgcolor="#FFFFFF" scope="row"><div align="left"><span class="precio_windows Estilo11">Configuraciones B&aacute;sicas para su Sitio Web</span></div></th>
          </tr>
        </table></th>
        </tr>
      <tr>
        <th height="564" colspan="2" scope="row" valign="top"><table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
          <tr bgcolor="#A7A7BE">
            <th height="145" bgcolor="#FFFFFF" class="dominio" scope="row"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <th width="7%" height="24" bgcolor="#FFFFFF" scope="row"><div align="left" class="dominio">
                  <div align="left" class="x_tsolo">
                    <div align="center"><img src="images/carpeta-ftp.jpg" alt="ftp" width="36" height="34" /></div>
                  </div>
                </div></th>
                <th width="37%" height="24" bgcolor="#FFFFFF" scope="row"><div align="left"><span class="Estilo12">&iquest;C&oacute;mo subo mi p&aacute;gina Web?</span></div></th>
                <th width="57%" bgcolor="#FFFFFF" scope="row">&nbsp;</th>
              </tr>
              <tr>
                <td height="96" colspan="3" scope="row"><div align="left">
                  <p class="Estilo13 Estilo23">El contenido de su sitio Web debe ser transferido desde su PC, utilizando cualquier cliente FTP. Para mayor informaci&oacute;n ingrese a: <a href="http://www.subituweb.com/faq/content/6/15/es/ftp-_-%BFc%F3mo-subo-archivos-por-ftp-file-transfer-protocol.html" target="_blank">http://www.subituweb.com/faq/content/6/15/es/ftp-_-%BFc%F3mo-subo-archivos-por-ftp-file-transfer-protocol.html</a></p>
                  <p class="Estilo13 Estilo23">Tenga en cuenta que su sitio Web debe contener un archivo inicial, este archivo debe llamarse <strong>index.htm</strong>, <strong>index.html</strong>, <strong>index.php</strong>, etc.</p>
                  <p class="Estilo13 Estilo23"><strong>IMPORTANTE</strong>: Una vez  subido el contenido de su p&aacute;gina Web y verificado que posee un archivo inicial adecuado (seg&uacute;n lo detallado anteriormente), usted deber&aacute; eliminar el archivo index.php (esta p&aacute;gina).</p>
                  </div></td>
                </tr>
            </table></th>
            </tr>
          
            <th class="dominio" scope="row"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              
                <th width="7%" height="31" scope="row"><img src="images/icono-nuevo-usuario.gif" alt="cpanel" width="34" height="27" /></th>
                <th width="50%" class="Estilo12" scope="row"><div align="left">&iquest;C&oacute;mo accedo a mi panel de control? </div></th>
                <th width="43%" height="31" scope="row">&nbsp;</th>
              
              <tr>
                <td height="46" colspan="3" scope="row"><div align="left" class="Estilo13 Estilo23">El panel de control de su servicio se utiliza para crear casillas de correo, cambiar la contrase&ntilde;a de su servicio, etc. Para obtener mayor informaci&oacute;n sobre como ingresar a su panel de control ingrese a: <a href="http://www.subituweb.com/faq/content/5/6/es/panel-de-control-cpanel-_-%BFc%F3mo-ingreso-a-mi-panel-de-control-en-servicios-linux.html" target="_blank">http://www.subituweb.com/faq/content/5/6/es/panel-de-control-cpanel-_-%BFc%F3mo-ingreso-a-mi-panel-de-control-en-servicios-linux.html</a><br />
                      <br />
                </div></td>
              </tr>
            </table></th>
     
          
          <tr>
            <th height="139" scope="row"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <th width="7%" height="31" scope="row"><img src="images/panel_llave.jpg" width="37" height="38"></th>
                <th width="53%" scope="row"><div align="left" class="Estilo12">&iquest;Qu&eacute; hago Si necesito informaci&oacute;n adicional / soporte t&eacute;cnico para mi servicio?</div></th>
                <th width="39%" height="31" scope="row">&nbsp;</th>
              </tr>
              <tr>
                <td height="77" colspan="3" scope="row"><div align="left">
                  <p class="Estilo13 Estilo23">En primer lugar le sugerimos buscar en nuestra secci&oacute;n de preguntas frecuentes (FAQ), ya que probablemente su consulta ya se encuentre documentada; para acceder a las preguntas frecuentes ingrese a: <a href="http://www.subituweb.com/faq" target="_blank">http://www.subituweb.com/faq</a></p>
                  <p><span class="Estilo13 Estilo23">Si la informaci&oacute;n que usted necesita no estuviera documentada, env&iacute;e su consulta a soporte@subituweb.com desde cualquiera de sus casillas de correo autorizadas. Son casillas de correo autorizadas aquellas casillas de correo que usted especific&oacute; en el formulario de solicitud, al mom&eacute;nto de contratar nuestros servicios.</span><br />
                  </p>
                </div></td>
                </tr>
            </table></th>
            </tr>
          <tr>
            <th height="39" scope="row"><span class="Estilo13 Estilo17"><span class="Estilo17">&iquest;Dudas? &iquest;Preguntas?. Consulte a nuestro servicio de preguntas frecuentes.</span></span> <a href="http://www.subituweb.com/faq" target="_blank" class="Estilo13">Haga click aqu&iacute; </a></th>
            </tr>
        </table></th>
        </tr>
      
    </table></th>
    <th height="432" valign="middle" background="images/borde_nr5.jpg"></th>
  </tr>
  
  <tr>
    <th width="14" height="14" valign="middle" nowrap="nowrap" scope="row"><img src="images/borde_lb5.gif" width="14" height="14"></th>
    <th height="14" valign="middle" nowrap="nowrap" background="images/borde_nb5.gif" scope="row"></th>
    <th width="14" height="14" valign="middle" nowrap="nowrap" scope="row"><img src="images/borde_rb5.gif" width="14" height="14"></th>
  </tr>
</table>
      <p>&nbsp;</p></th>
  </tr>
</table>
<blockquote>
  <p>&nbsp;</p>
</blockquote>
</div>
</body>
