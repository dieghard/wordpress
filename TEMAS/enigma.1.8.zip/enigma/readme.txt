****NOTE****
ALL PRE-FIX used in the Enigma is used the PRE-FIXED for all theme by the Weblizar.
Consider weblizar PRE-Fix for function-name and as a slug of the Theme Enigma.

Enigma

CHANGE-LOG:
@Version: 1.8[24/01/2015]
1. Custom Static Front-Page.
2.


@Version: 1.7.2[21/01/2015]
1. Unminified JS.


@Version: 1.7.1[16/01/2015]
1. Title Repetition Removed.
2. Unused JS file removed.
3. Pagw with Left Sidebar added. 

@Version: 1.7 [05/01/15]
1. Editor added in Theme-Options.
2. Discount Coupon Removed.
3. FA link updated.
4. Portfolio Link Title fixed.  

@Version: 1.6.1 [09/12/14]
1.Minor Translated String

@Version: 1.6 [04/12/14]
1. Snow Effects in Theme-Options.
2. Two More SOcial Icons.
3. iPad Drop-Down Fixed

@Version: 1.5.1 [19/11/14]
1. Minor FIX in blog file
2. Log image to add css for mobile view

@Version: 1.5 [05/11/14]
1. Minor FIX

@Version: 1.4.3 [05/11/14]
1. DATE Format Issue Fixed.


@Version: 1.4.2 [13/10/14]
1.)All Issue Raised By Reviewer Fixed.
2.) iPAD menu Issue Fixed.

@Version: 1.4 [13/10/14]
1. Child theme ready.
2. Social media link modify with #. ( Advise by gpriday )

@Version: 1.4 [13/10/14]
1. Menu Implementation for mobiles.

@Version: 1.3 [11/10/14]
1.	Top Menu Implementation.
2.	Woo-commerce Ready.
3.	Full-Width Page.
4.	Telephone Icon Issue Fixed.
5. 	Search URL issue Fixed.
6.  Admin side Image Added.

@Version: 1.2 [05/10/14]
1. Sane Default Concept added.
@Version: 1.1 [27/09/14]
1) comment_function Issue fixed.
2) White Space Issue Fixed.
3) Portfolio Check box Enable.

@Version: 1.0 [06/08/14]
Rest all issue fixed.
@Version 0.99 [03/08/14]
->Issue raised after first review removed here.
@Version 0.9.5
released
/////////////////////////*****************Copyrights Attribution********************////////////////////////////////////
Enigma WordPress Theme, Copyright 2014 weblizar
Enigma is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see .

Enigma WordPress Theme bundles the following third-party resources:
Snow-fall JS : http://www.schillmania.com/projects/snowstorm/license.txt
Licensed under: BSD


Bootstrap jQuery library, Copyright 2013  Twitter, Inc.
Licensed under http://www.apache.org/licenses/LICENSE-2.0
Source: https://github.com/twbs/bootstrap/archive/v3.0.2.zip

jQuery carouFredSel |  v6.2.1 | (c) 2013    | 
jQuery carouFredSel , Copyright 2013 Ivan Fred Heusschen , http://www.frebsite.nl
Licensed under MIT license :http://opensource.org/licenses/MIT
Source:https://github.com/gilbitron/carouFredSel

Photobox jQuery |   v1.9 | 
(c) 2013  Yair Even.,(http://dropthebit.com)
Licensed under MIT license :https://jquery.org/license/


jQuery Waypoints | v2.0.3 |
Copyright (c) 2011-2013 Caleb Troughton
Dual licensed under the MIT license and GPL license.
https://github.com/imakewebthings/jquery-waypoints/blob/master/licenses.txt

menu.js
Just to make hover effects of the menu.

Scroll JS | V 1.0 | weblizar 
(c) 2014  | Licensed under the MIT license and GPL license.

Enigma_Theme_Script | V 1.0 | weblizar 
(c) 2014  | Licensed under the MIT license and GPL license.

Theme-Footer-Script | V 1.0 | weblizar 
(c) 2014  | Licensed under the MIT license and GPL license.
/*****BUNDELED CSS***/
Font Awesome CSS |  v3.2.1 | 
Copyright 2014  Dave Gandy.,
Licensed under MIT license :http://opensource.org/licenses/MIT
Source:http://fortawesome.github.io/Font-Awesome/assets/font-awesome-3.2.1.zip

Bootstrap CSS |  v3.1.1 | 
Copyright 2011-2014 Twitter, Inc
Licensed under the Apache License v2.0 http://www.apache.org/licenses/LICENSE-2.0
Source:http://getbootstrap.com/getting-started#download

Animations CSS |  v1.0 | 
Copyright 2014 weblizar
Licensed under GPL

Animations CSS |  v1.0 | 
Copyright 2014 weblizar
Licensed under GPL

Enigma Theme CSS |  v1.0 | 
Copyright 2014 weblizar
Licensed under GPL

Photo Box CSS  |  v1.0 | 
Copyright 2014 weblizar
Licensed under GPL

Theme Animate CSS  |  v1.0 | 
Copyright 2014 weblizar
Licensed under GPL

Images Taken from :
pixabay.com

Image Slide 1: http://pixabay.com/en/new-york-city-brooklyn-bridge-night-336475/
Image Slide 2:http://pixabay.com/en/tractor-field-landscape-campaign-396477/
Image Slide 3:http://pixabay.com/en/nice-c%C3%B4te-d---azur-france-398051/

=================Portfolio Images URL ====================
http://pixabay.com/en/girl-portrait-outdoors-pretty-344335/
http://pixabay.com/en/keyboard-apple-input-keys-hardware-338507/
http://pixabay.com/en/lamborghini-sports-car-racing-car-188960/
http://pixabay.com/en/skydive-parachute-parachuting-79548/
==============================================================
All Images have been used in the Enigma, Created by weblizar .Also they are GPL Licensed and free to use and free to redistribute further. 
# --- EOF --- #